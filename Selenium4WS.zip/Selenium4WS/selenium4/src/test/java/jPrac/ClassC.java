package jPrac;

public class ClassC extends ClassB {

	public void cat() {
		System.out.println("Method cat");
	}

	public void cap() {
		System.out.println("Method cap");
	}

	public void cool() {
		System.out.println("Method cool");
	}

	public void balloon() {
System.out.println("Class C Balloon");
	}
	
	public void apple() {
		System.out.println("Class C apple");
	}
}

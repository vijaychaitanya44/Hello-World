package jPrac;

public class ClassB extends ClassA {

	public void ball() {
		System.out.println("Method Ball");
	}

	public void bat() {
		System.out.println("Method Bat");
	}

	public void bag() {
		System.out.println("Method Bag");
	}

	public void balloon() {
System.out.println("Method Balloon");
	}
	
	public void apple() {
		System.out.println("CLass B apple");
	}
}

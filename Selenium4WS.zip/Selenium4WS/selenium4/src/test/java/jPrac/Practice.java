package jPrac;

public class Practice {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		ClassA a = new ClassA();
		
		a.apple();
		
		ClassA a1 = new ClassB();
		a1.apple();
		
		
		ClassA a2 = new ClassC();
		a2.apple();
		
		
		
		ClassC c = new ClassC();
		
		c.apple();
		c.ball();
		c.cat();

	}

}

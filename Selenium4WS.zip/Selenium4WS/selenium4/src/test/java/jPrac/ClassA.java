package jPrac;

public class ClassA {
	
	public void apple() {
		System.out.println("Method Apple");
	}
	
	public void axe() {
		System.out.println("Method Axe");
	}
	
	public void air() {
		System.out.println("Method Air");
	}
	
	public void aeroplane() {
		System.out.println("Method Aeroplane");
	}

}
